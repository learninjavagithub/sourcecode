package com.learninjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Application - WebClient Example
 * 
 * @author learninjava.com
 *
 */
@SpringBootApplication
public class SpringBootWebClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebClientApplication.class, args);
	}

}
