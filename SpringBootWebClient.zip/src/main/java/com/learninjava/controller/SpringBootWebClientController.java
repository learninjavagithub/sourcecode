package com.learninjava.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.learninjava.model.Post;

import reactor.core.publisher.Mono;

/**
 * Controller - Example of WebClient CRUD
 * 
 * @author learninjava.com
 *
 */
@RestController
@RequestMapping("/microservice/webclient")
public class SpringBootWebClientController {

	@Autowired
	WebClient createWebClient;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/v1/post/{id}")
	public ResponseEntity<Mono<Post>> getPost(@PathVariable String id) {
	
		Mono<Post> postMono = createWebClient.get()
				.uri("/posts/" + id)
				.retrieve()
				.bodyToMono(Post.class);
		
		return new ResponseEntity(postMono, HttpStatus.OK);
	}
	
	@PostMapping(path="/v1/post", consumes=MediaType.APPLICATION_JSON_VALUE, 
			produces=MediaType.APPLICATION_JSON_VALUE)
	public Mono<Post> createPost(@RequestBody Post post) {
		
		return createWebClient.post()
				 .uri("/posts")
				 .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				 .body(BodyInserters.fromValue(post))
				 .retrieve()
				 .bodyToMono(Post.class);
	}
	
	@PutMapping(path="/v1/post", consumes=MediaType.APPLICATION_JSON_VALUE)
	public Mono<Post> updatePost(@RequestBody Post post) {
		
		return createWebClient.put()
				 .uri("/posts/1")
				 .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				 .body(BodyInserters.fromValue(post))
				 .retrieve()
				 .bodyToMono(Post.class);
	}
	
	@DeleteMapping(path="/v1/post/{id}")
	public Mono<Post> deletePost(@PathVariable String id) {
		
		return createWebClient.delete()
				 .uri("/posts/" + id)
				 .retrieve()
				 .bodyToMono(Post.class);
	}	
}
