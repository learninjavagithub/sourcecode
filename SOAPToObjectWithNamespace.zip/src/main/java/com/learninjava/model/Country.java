package com.learninjava.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
@lombok.Data
public class Country implements Serializable {

	private static final long serialVersionUID = 1L;

	@XmlAttribute(name = "Name")
	private String name;

	@XmlAttribute(name = "Code")
	private String code;

	@XmlAttribute(name = "Continent")
	private String continent;

	@XmlElement(name = "State", namespace = "http://www.learninjava.com/soaptoobject/1_0/")
	private List<State> state;

	@XmlAccessorType(XmlAccessType.FIELD)
	@lombok.Data
	public static class State implements Serializable {

		private static final long serialVersionUID = 1L;

		@XmlAttribute(name = "Name")
		private String name;

		@XmlAttribute(name = "StateCode")
		private String stateCode;

		@XmlAttribute(name = "Code")
		private String code;
	}
}
