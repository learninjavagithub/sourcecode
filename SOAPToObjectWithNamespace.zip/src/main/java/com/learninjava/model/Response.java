package com.learninjava.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Response", namespace = "http://www.learninjava.com/soaptoobject/1_0/")
@lombok.Data
public class Response implements Serializable {

	private static final long serialVersionUID = 1L;

	@XmlElement(name = "Country", namespace = "http://www.learninjava.com/soaptoobject/1_0/")
	private Country country;

	@XmlElement(name = "Demographics", namespace = "http://www.learninjava.com/soaptoobject/1_0/")
	private Demographics demographics;
	
	@XmlAccessorType(XmlAccessType.FIELD)
	@lombok.Data	
	public static class Demographics implements Serializable {

		private static final long serialVersionUID = 1L;

		@XmlAttribute(name = "Capital")
		private String capital;

		@XmlAttribute(name = "Language")
		private String language;

		@XmlAttribute(name = "Currency")
		private String currency;
	}	
}
