package com.learninjava;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.oxm.XmlMappingException;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.learninjava.model.Country;
import com.learninjava.model.Response;

@SpringBootApplication
public class SoapToObjectWithNamespaceApplication {
	
	@Autowired
	ServiceUtils serviceUtils;
	
	private static final String XML_MSG = "<SOAP-ENV:Envelope\n" + 
			"   xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\"\n" + 
			"   xmlns:lij=\"http://www.learninjava.com/soaptoobject/1_0/\"\n" + 
			"   SOAP-ENV:encodingStyle=\n" + 
			"           \"http://schemas.xmlsoap.org/soap/encoding/\">\n" + 
			"      <SOAP-ENV:Body>\n" + 
			"      	<lij:Response>\n" + 
			"          <lij:Country Name=\"US\" Code=\"1\" Continent=\"NA\">\n" + 
			"              <lij:State Name=\"Texas\" StateCode=\"TX\" Code=\"713\" />\n" + 
			"              <lij:State Name=\"Georgia\" StateCode=\"GA\" Code=\"678\" />\n" + 
			"              <lij:State Name=\"Arizona\" StateCode=\"AZ\" Code=\"480\" />\n" + 
			"          </lij:Country>\n" + 
			"          <lij:Demographics Capital=\"Washington\" Language=\"English\" Currency=\"Dollar\" />\n" + 
			"        </lij:Response>\n" + 
			"      </SOAP-ENV:Body>\n" + 
			"</SOAP-ENV:Envelope>";
	
    @PostConstruct
    public void init() throws 
    	XmlMappingException, XMLStreamException, JAXBException, SOAPException, IOException  {

    	// Convert XML to SOAPMessage
		SOAPMessage soapMessage = createSOAPMessage(XML_MSG);    
		System.out.println("\n\n--- Print SOAPMessage as String --- \n" + getStringFromSOAPMessage(soapMessage));

		// 1. Get Object from SOAPMessage using Jaxb2Marshaller
		Response responseOneMore = serviceUtils.unmarshall(soapMessage, Response.class);
		System.out.println("\n\n--- Using Jaxb2Marshaller Object ---");
		System.out.println("Element's Attribute: " + responseOneMore.getCountry().getName());
		
		// Print some stuff
		List<Country.State> statesOneMore = responseOneMore.getCountry().getState();
		System.out.println("Sub Element List's Attribute: " + statesOneMore.get(1).getName());
		System.out.println("Another Element's Attribute: " + responseOneMore.getDemographics().getCapital());
		System.out.println("\n\n");
    }	
	
    public static void main(String[] args) throws 
		XMLStreamException, JAXBException, SOAPException, XmlMappingException, IOException {
    	
		SpringApplication.run(SoapToObjectWithNamespaceApplication.class, args);
		
		// Convert XML to SOAPMessage
		SOAPMessage soapMessage = createSOAPMessage(XML_MSG);
		// Print the SOAPMessage to validate for correctness
		System.out.println("\n\n--- Lets print the SOAP XML --- \n" + getStringFromSOAPMessage(soapMessage));
		
		// 2. Get Object from SOAPMessage using XMLStreamReader
		Response response = getObjectFromSOAPMessageUsingXMLStreamReader(soapMessage, Response.class);
		System.out.println("\n\n--- Using XMLStreamReader ---"); 
		System.out.println("Element's Attribute: " + response.getCountry().getName());
		
		// Print some stuff
		List<Country.State> states = response.getCountry().getState();
		System.out.println("Sub Element List's Attribute: " + states.get(1).getName());
		System.out.println("Another Element's Attribute: " + response.getDemographics().getCapital());
		
		// 3. Get Object from SOAPMessage using Document Object
		Response responseAgain = getObjectFromSOAPMessageUsingDocument(soapMessage, Response.class);
		System.out.println("\n\n--- Using Document Object ---");
		System.out.println("Element's Attribute: " + responseAgain.getCountry().getName());
		
		// Print some stuff
		List<Country.State> statesAgain = responseAgain.getCountry().getState();
		System.out.println("Sub Element List's Attribute: " + statesAgain.get(1).getName());
		System.out.println("Another Element's Attribute: " + responseAgain.getDemographics().getCapital());
		
		// Some utility methods
		// 1. Get Document object from XML string
		Document document = getDocumentFromXMLString(XML_MSG);
		// Print and validate
		System.out.println("\n\n--- Print Document as String --- \n" + getStringFromDocument(document));
		
		// 2. Get String from SOAPMessage using Stream
		System.out.println("\n\n--- Print SOAPMessage using stream --- \n" + getStringFromSOAPMessageUsingStream(soapMessage));
	}
	
	private static SOAPMessage createSOAPMessage(String xmlMessage) throws SOAPException {

		// Get SOAPMessage object from XML String
		SOAPMessage soapMessage = getSOAPMessageFromXMLString(xmlMessage, "lij", "http://www.learninjava.com/soaptoobject/1_0/");
		// Add some headers
		SOAPHeader soapHeader = soapMessage.getSOAPPart().getEnvelope().addHeader();
		
		SOAPHeaderElement commonHeader = soapHeader.addHeaderElement(new QName("http://www.learninjava.com/common/1_0", "LIJHeader", "lijcommon"));
		
		commonHeader.addAttribute(new QName("Version"), "1.0");
		commonHeader.addAttribute(new QName("MsgID"), UUID.randomUUID().toString());
		commonHeader.addAttribute(new QName("Timestamp"), new Date().toString());
		
		soapMessage.saveChanges();
		return soapMessage;
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T getObjectFromSOAPMessageUsingDocument(SOAPMessage soapMessage, Class<T> type) throws XMLStreamException,
		JAXBException, SOAPException {
		
		Unmarshaller unmarshaller = JAXBContext.newInstance(type).createUnmarshaller();
		T response = (T) unmarshaller.unmarshal(soapMessage.getSOAPBody().extractContentAsDocument());
		
		return response;
	}
	
	public static <T> T getObjectFromSOAPMessageUsingXMLStreamReader(SOAPMessage soapMessage, Class<T> type) {
		
		XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
		XMLStreamReader xmlStreamReader = null;
		JAXBElement<T> jaxbElement = null;
		try {
			xmlStreamReader = xmlInputFactory.createXMLStreamReader(new StringReader(getStringFromSOAPMessage(soapMessage)));
			xmlStreamReader.nextTag();
			while (!xmlStreamReader.getLocalName().equals(type.getSimpleName())) {
				xmlStreamReader.nextTag();
			}
			Unmarshaller unmarshaller = JAXBContext.newInstance(type).createUnmarshaller();
			jaxbElement = unmarshaller.unmarshal(xmlStreamReader, type);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				xmlStreamReader.close();
			} catch (XMLStreamException e) {
				e.printStackTrace();
			}
		}
		return jaxbElement.getValue();
	}
	
	public static SOAPMessage getSOAPMessageFromXMLString(String xmlString,
			String namespacePrefix, String namespaceURI) {
		
		SOAPMessage soapMessage = null;
		try {
			InputStream is = new ByteArrayInputStream(xmlString.getBytes());
			soapMessage = MessageFactory.newInstance().createMessage(null, is);
			
			SOAPEnvelope soapEnvelope = soapMessage.getSOAPPart().getEnvelope();
			soapEnvelope.addNamespaceDeclaration(namespacePrefix, namespaceURI);

			soapMessage.saveChanges();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return soapMessage;
	}

	private static Document getDocumentFromXMLString(String xmlString) {
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
		dbFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
		
		DocumentBuilder dBuilder;
		try {
			dbFactory.setNamespaceAware(true);
			dBuilder = dbFactory.newDocumentBuilder();
			
			return dBuilder.parse(new InputSource(new StringReader(xmlString)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private static String getStringFromSOAPMessage(SOAPMessage soapMessage) {
		
		final StringWriter sw = new StringWriter();
		try {
			TransformerFactory.newInstance().newTransformer().transform(
			        new DOMSource(soapMessage.getSOAPPart()),
			        new StreamResult(sw));
		} catch (TransformerException | TransformerFactoryConfigurationError e) {
			e.printStackTrace();
		}
		return sw.toString();
	}
		
	private static String getStringFromDocument(Document document) {
		
		final StringWriter sw = new StringWriter();
		try {
			TransformerFactory.newInstance().newTransformer().transform(
			        new DOMSource(document),
			        new StreamResult(sw));
		} catch (TransformerException | TransformerFactoryConfigurationError e) {
			e.printStackTrace();
		}
		return sw.toString();
	}
	
	private static String getStringFromSOAPMessageUsingStream(SOAPMessage soapMessage) {
		
		OutputStream os = new ByteArrayOutputStream();
		try {
			soapMessage.writeTo(os);
		} catch (SOAPException | IOException e) {
			e.printStackTrace();
		}
		return os.toString();
	}
}
