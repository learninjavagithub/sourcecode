package com.learninjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapToObjectWithNamespaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
