package com.learninjava.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Body", namespace = "http://www.learninjava.com/soaptoobject/1_0/")
@lombok.Data
public class Body {
	
	@XmlElement(name = "Response", namespace = "http://www.learninjava.com/soaptoobject/1_0/")
	private Response response;
}
