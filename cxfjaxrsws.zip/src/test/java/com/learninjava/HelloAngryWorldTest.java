package com.learninjava;

import static org.junit.Assert.assertEquals;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.jaxrs.client.spec.InvocationBuilderImpl;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.MappingJsonFactory;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author learninjava.com
 * @see www.learninjava.com
 */
public class HelloAngryWorldTest {
    private static String endpointUrl;

    @BeforeClass
    public static void beforeClass() {
        endpointUrl = System.getProperty("service.url");
    }

    @Test
    public void testPing() throws Exception {
        WebClient client = WebClient.create(endpointUrl + "/helloAngryWorld/echo/Tweet");
        Response r = client.accept("text/plain").get();
        assertEquals(Response.Status.OK.getStatusCode(), r.getStatus());
        String value = IOUtils.toString((InputStream)r.getEntity());
        System.out.println("Response from web service is : " + value);
        assertEquals("Tweet", value);
    }

    @Test
    public void testPingUsingPureJaxRS() throws Exception {
    	
    	Client client = ClientBuilder.newClient();
    	WebTarget target = client.target(endpointUrl + "/helloAngryWorld/echo/Tweet");
    	Invocation.Builder builder = target.request("text/plain"); 
    	Response r = builder.get();
    	
        assertEquals(Response.Status.OK.getStatusCode(), r.getStatus());
        String value = IOUtils.toString((InputStream)r.getEntity());
        System.out.println("Response from web service is : " + value);
        assertEquals("Tweet", value);
    }

    @Test
    public void testJsonRoundtrip() throws Exception {
        List<Object> providers = new ArrayList<Object>();
        providers.add(new org.codehaus.jackson.jaxrs.JacksonJsonProvider());
        
        JsonBean inputBean = new JsonBean();
        inputBean.setVal1("Birds");
        
        WebClient client = WebClient.create(endpointUrl + "/helloAngryWorld/jsonBean", providers);
        Response r = client.accept("application/json")
            .type("application/json")
            .post(inputBean);
        
        assertEquals(Response.Status.OK.getStatusCode(), r.getStatus());
        
        MappingJsonFactory factory = new MappingJsonFactory();
        JsonParser parser = factory.createJsonParser((InputStream)r.getEntity());
        JsonBean output = parser.readValueAs(JsonBean.class);
        System.out.println("Response from web service is : " + output.getVal2()); 
        assertEquals("Birds", output.getVal2());
    }
}
