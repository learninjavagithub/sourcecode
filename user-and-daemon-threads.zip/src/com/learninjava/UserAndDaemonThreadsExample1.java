package com.learninjava;

/**
 * @author www.learninjava.com
 */
public class UserAndDaemonThreadsExample1 {
	
	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		
		Thread daemonThread = new Thread(new Runnable() {
			
			public void run() {
				
				while ( true ) {
					System.out.println("In run method of daemon thead...");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					} finally {
						System.out.println("In finally method of daemon thread...");
					}
				}
				
			}
		});
		daemonThread.setDaemon(true);
		daemonThread.start();
		
		//Uncomment this and re-run to see that the JVM waits if join is present         
		//daemonThread.join(); 

		System.out.println("Exiting main thread...");
	}

}
