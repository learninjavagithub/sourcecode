import Dashboard from "./Dashboard.js";

const Routes = [
  {
    path: "/",
    component: Dashboard
  }
];

export default Routes;
