package com.learninjava;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;

// Classes used by Pure JAX-RS API client
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;

/*
// Classes used by Jersey API Client
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
*/

import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author learninjava.com
 * @see www.learninjava.com
 */
public class HelloAngryWorldTest {
    private static String endpointUrl;

    @BeforeClass
    public static void beforeClass() {
        endpointUrl = System.getProperty("service.url");
    }

    /**
     * This method uses the Pure JAX-RS API to create a client.
     *
     * Comment the following to run this client :
     * 1. testPingUsingJersey() in this file
     * 2. Jersey API imports in this file
     * 3. Jersey client dependencies in pom.xml
     */
    @Test
    public void testPingUsingPureJaxRS() throws Exception {
    	
    	Client client = ClientBuilder.newClient();
    	WebTarget target = client.target(endpointUrl + "/helloAngryWorld/echo/Tweet");
    	Invocation.Builder builder = target.request("text/plain"); 
    	Response response = builder.get();
    	
      assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
      String value = builder.get( String.class);
      System.out.println("Response from web service is : " + value);
      assertEquals("Tweet", value);
    }


    /**
     * This method uses the Jersey API to create a client.
     *
     * Comment the following to run this client :
     * 1. testPingUsingPureJaxRS() in this file
     * 2. Pure JAX-RS imports in this file
     * 3. Pure JAX-RS client dependencies in pom.xml
     */
/*    @Test
    public void testPingUsingJersey() throws Exception {
    	
    	ClientConfig config = new DefaultClientConfig();
      Client client = Client.create(config);
      WebResource webresource = client.resource(endpointUrl + "/helloAngryWorld/echo/Tweet");    	
      ClientResponse response = webresource.accept("text/plain").get(ClientResponse.class);

      assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
      String value = webresource.get(String.class);
      System.out.println("Response from web service is : " + value);
      assertEquals("Tweet", value);
    }
*/
}