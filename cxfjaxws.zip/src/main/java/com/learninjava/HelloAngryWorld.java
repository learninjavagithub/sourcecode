package com.learninjava;

import javax.jws.WebService;

/**
 * @author learninjava.com
 * @see www.learninjava.com
 */
@WebService
public interface HelloAngryWorld {
    String sayHi(String text);
}

